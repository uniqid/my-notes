<?php
require("common.php");

if(!get_magic_quotes_gpc()){
    //add_magic_quotes();
}

//Code fragments
if(isset($_GET['keyword'])){
    $keyword = $_GET['keyword'];
    //$keyword = str_replace("'", "''", $keyword);
    $sql = "select * from news where title like '%{$keyword}%'";
}
else{
    $sql = "select * from news";
}
//Code fragments


$str = file_get_contents($_SERVER['SCRIPT_FILENAME']);
$str = preg_replace("/.*?\/\/Code fragments(.*?)\/\/Code fragments.*/is", "$1", $str);
show("Code fragments", $str);
echo "<br/><br/>";

$str = urldecode("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
show("url", $str);
show("sql", $sql);
$results = fetchAll($sql);
show("results", $results);
?>