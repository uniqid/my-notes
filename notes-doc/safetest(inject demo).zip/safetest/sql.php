		<?php phpinfo(); ?>
