<?php
require("common.php");


//Code fragments
if(isset($_GET['username']) && isset($_GET['password'])){
    $username = trim($_GET['username']);
    $password = md5(trim($_GET['password']));
}
else{
    exit("Parameter error");
}
$sql = "insert into admin(username,password) values('{$username}', '{$password}')";
//Code fragments


$str = file_get_contents($_SERVER['SCRIPT_FILENAME']);
$str = preg_replace("/.*?\/\/Code fragments(.*?)\/\/Code fragments.*/is", "$1", $str);
show("Code fragments", $str);
echo "<br/>";

$str = urldecode("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
show("url", $str);
show("sql", $sql);
mysql_query($sql);

//$results = fetchAll($sql, true);
//show("results", $results);

?>