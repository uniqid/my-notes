<?php
require("common.php");


//Code fragments
if(isset($_GET['id'])){
    $id  = $_GET['id'];
}
else{
    exit("Parameter error");
}
$sql = "select * from news where id={$id}";
//Code fragments


$str = file_get_contents($_SERVER['SCRIPT_FILENAME']);
$str = preg_replace("/.*?\/\/Code fragments(.*?)\/\/Code fragments.*/is", "$1", $str);
show("Code fragments", $str);
echo "<br/>";

$str = urldecode("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
show("url", str_replace("<", "&lt;", $str));
show("sql", str_replace("<", "&lt;", $sql));
$results = fetchAll($sql, true);
show("results", $results);
?>