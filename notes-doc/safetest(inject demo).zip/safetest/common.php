<?php

if(!get_magic_quotes_gpc()){
    //add_magic_quotes();
}

$conn = mysql_connect('localhost', 'root', 'flyfish') or die("Could not connect: " . mysql_error());
mysql_select_db("safetest");
mysql_query("set names utf8");

function fetchAll($sql, $first = false) {
    if($result = mysql_query($sql)){
        if($first){
            if($row = mysql_fetch_array($result, MYSQL_ASSOC)){
                return $row;
            }
        }
        else{
            $rows = array();
            while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
                $rows[] = $row;
            }
            return $rows;
        }
    }
    return array();
}

function show($name, $value) {
    if(is_array($value) || $name=="Code fragments"){
        echo $name ." start ". str_repeat("-", 60 - strlen($name))."<br/><div style='color:red;font-weight:bold;'>";
        echo "<pre>";
        print_r($value);
        echo "</pre>";
    }
    else{
        echo $name ." start ". str_repeat("-", 60 - strlen($name))."<br/><div style='color:red;font-weight:bold;'>";
        echo $value."<br />"; 
    }
    echo "</div>". $name ." end ". str_repeat("-", 62 - strlen($name))."<br/><br/>";
}

function add_magic_quotes() {
    $_POST    = array_map("deep_addslashes" , $_POST);
    $_GET     = array_map("deep_addslashes" , $_GET);
    $_COOKIE  = array_map("deep_addslashes" , $_COOKIE);
    $_REQUEST = array_map("deep_addslashes" , $_REQUEST);
}

function deep_addslashes($data) {
    if(is_array($data)){
        foreach($data as $key => $_data){
            $data[$key] = is_array($_data)? deep_addslashes($_data): addslashes($_data);
        }
        return $data;
    }
    else{
        return addslashes($data);
    }
}

?>